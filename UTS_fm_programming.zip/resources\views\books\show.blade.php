@extends('layouts.app')

@section('title', 'Detail Book')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Detail Book</h1>

    <a href="{{ route('books.index') }}" class="btn btn-secondary">
        Back
    </a>
</div>

<div class="card">
    <div class="card-body">

        <table class="table">
            <tr>
                <th width="200">ID</th>
                <td>{{ $book->id }}</td>
            </tr>

            <tr>
                <th>Title</th>
                <td>{{ $book->title }}</td>
            </tr>

            <tr>
                <th>Published Year</th>
                <td>{{ $book->published_year }}</td>
            </tr>

            <tr>
                <th>Category</th>
                <td>{{ $book->category->name }}</td>
            </tr>

        </table>

        <a href="{{ route('books.edit', $book) }}" class="btn btn-warning">
            Edit
        </a>

    </div>
</div>

@endsection