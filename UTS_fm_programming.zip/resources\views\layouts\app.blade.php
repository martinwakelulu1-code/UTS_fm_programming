<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>@yield('title', 'Book Management')</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="{{ route('books.index') }}">
                Book Management
            </a>

            <div>
                <a href="{{ route('books.index') }}" class="btn btn-outline-light btn-sm">
                    Books
                </a>

                <a href="{{ route('categories.index') }}" class="btn btn-outline-light btn-sm">
                    Categories
                </a>
            </div>
        </div>
    </nav>

    <main class="container">
        @yield('content')
    </main>

</body>
</html>