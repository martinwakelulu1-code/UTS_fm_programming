@extends('layouts.app')

@section('title', 'Books')

@section('content')

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
@endif

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Books</h1>

    <a href="{{ route('books.create') }}" class="btn btn-primary">
        + Add Book
    </a>
</div>

<div class="card">
    <div class="card-body">

        @if($books->count() > 0)

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Published Year</th>
                        <th>Category</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($books as $book)
                        <tr>
                            <td>{{ $book->id }}</td>
                            <td>{{ $book->title }}</td>
                            <td>{{ $book->published_year }}</td>
                            <td>{{ $book->category->name }}</td>
                            <td>
                                <a href="{{ route('books.show', $book) }}"
                                   class="btn btn-info btn-sm">
                                    View
                                </a>

                                <a href="{{ route('books.edit', $book) }}"
                                   class="btn btn-warning btn-sm">
                                    Edit
                                </a>

                                <form action="{{ route('books.destroy', $book) }}"
      method="POST"
      class="d-inline"
      onsubmit="return confirm('Yakin ingin menghapus buku ini?')">

    @csrf
    @method('DELETE')

    <button type="submit" class="btn btn-danger btn-sm">
        Delete
    </button>

</form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

        @else

            <p class="text-muted mb-0">
                Belum ada buku.
            </p>

        @endif

    </div>
</div>

@endsection