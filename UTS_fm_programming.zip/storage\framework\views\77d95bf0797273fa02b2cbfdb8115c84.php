

<?php $__env->startSection('title', 'Detail Book'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Detail Book</h1>

    <a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary">
        Back
    </a>
</div>

<div class="card">
    <div class="card-body">

        <table class="table">
            <tr>
                <th width="200">ID</th>
                <td><?php echo e($book->id); ?></td>
            </tr>

            <tr>
                <th>Title</th>
                <td><?php echo e($book->title); ?></td>
            </tr>

            <tr>
                <th>Published Year</th>
                <td><?php echo e($book->published_year); ?></td>
            </tr>

            <tr>
                <th>Category</th>
                <td><?php echo e($book->category->name); ?></td>
            </tr>

        </table>

        <a href="<?php echo e(route('books.edit', $book)); ?>" class="btn btn-warning">
            Edit
        </a>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\UTS_fm_programming\uts-framework\resources\views/books/show.blade.php ENDPATH**/ ?>