@extends('layouts.app')

@section('title', 'Detail Category')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Detail Category</h1>

    <a href="{{ route('categories.index') }}" class="btn btn-secondary">
        Back
    </a>
</div>

<div class="card mb-4">
    <div class="card-body">
        <h4>{{ $category->name }}</h4>
        <p class="text-muted mb-0">
            Daftar buku dalam kategori ini
        </p>
    </div>
</div>

<div class="card">
    <div class="card-body">

        @if($category->books->count() > 0)

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Published Year</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($category->books as $book)
                        <tr>
                            <td>{{ $book->id }}</td>
                            <td>{{ $book->title }}</td>
                            <td>{{ $book->published_year }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

        @else

            <p class="text-muted mb-0">
                Belum ada buku dalam kategori ini.
            </p>

        @endif

    </div>
</div>

@endsection