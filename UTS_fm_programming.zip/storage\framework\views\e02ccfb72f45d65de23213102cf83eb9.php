

<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Categories</h1>

    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">
        + Add Category
    </a>
</div>

<div class="card">
    <div class="card-body">

        <?php if($categories->count() > 0): ?>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="10%">ID</th>
                        <th>Name</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('categories.show', $category)); ?>"
                                   class="btn btn-info btn-sm">
                                    View
                                </a>

                                <a href="<?php echo e(route('categories.edit', $category)); ?>"
                                   class="btn btn-warning btn-sm">
                                    Edit
                                </a>
                                <form action="<?php echo e(route('categories.destroy', $category)); ?>"
      method="POST"
      class="d-inline"
      onsubmit="return confirm('Yakin ingin menghapus category ini?')">

    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>

    <button type="submit" class="btn btn-danger btn-sm">
        Delete
    </button>
</form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        <?php else: ?>

            <p class="text-muted mb-0">
                Belum ada kategori.
            </p>

        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\UTS_fm_programming\uts-framework\resources\views/categories/index.blade.php ENDPATH**/ ?>