@extends('layouts.app')

@section('title', 'Categories')

@section('content')

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
@endif

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Categories</h1>

    <a href="{{ route('categories.create') }}" class="btn btn-primary">
        + Add Category
    </a>
</div>

<div class="card">
    <div class="card-body">

        @if($categories->count() > 0)

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="10%">ID</th>
                        <th>Name</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($categories as $category)
                        <tr>
                            <td>{{ $category->id }}</td>
                            <td>{{ $category->name }}</td>
                            <td>
                                <a href="{{ route('categories.show', $category) }}"
                                   class="btn btn-info btn-sm">
                                    View
                                </a>

                                <a href="{{ route('categories.edit', $category) }}"
                                   class="btn btn-warning btn-sm">
                                    Edit
                                </a>
                                <form action="{{ route('categories.destroy', $category) }}"
      method="POST"
      class="d-inline"
      onsubmit="return confirm('Yakin ingin menghapus category ini?')">

    @csrf
    @method('DELETE')

    <button type="submit" class="btn btn-danger btn-sm">
        Delete
    </button>
</form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

        @else

            <p class="text-muted mb-0">
                Belum ada kategori.
            </p>

        @endif

    </div>
</div>

@endsection