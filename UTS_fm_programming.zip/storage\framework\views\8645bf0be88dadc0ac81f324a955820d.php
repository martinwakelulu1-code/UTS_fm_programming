

<?php $__env->startSection('title', 'Detail Category'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Detail Category</h1>

    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">
        Back
    </a>
</div>

<div class="card mb-4">
    <div class="card-body">
        <h4><?php echo e($category->name); ?></h4>
        <p class="text-muted mb-0">
            Daftar buku dalam kategori ini
        </p>
    </div>
</div>

<div class="card">
    <div class="card-body">

        <?php if($category->books->count() > 0): ?>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Published Year</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $category->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($book->id); ?></td>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->published_year); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        <?php else: ?>

            <p class="text-muted mb-0">
                Belum ada buku dalam kategori ini.
            </p>

        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\UTS_fm_programming\uts-framework\resources\views/categories/show.blade.php ENDPATH**/ ?>