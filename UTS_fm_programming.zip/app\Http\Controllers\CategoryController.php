<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::all();

        return view('categories.index', compact('categories'));
    }

    public function create()
    {
        return view('categories.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:categories,name'],
        ]);

        Category::create($validated);

        return redirect()
            ->route('categories.index')
            ->with('success', 'Category berhasil ditambahkan.');
    }

    public function show(Category $category)
    {
        $category->load('books');

        return view('categories.show', compact('category'));
    }

    public function edit(Category $category)
    {
        return view('categories.edit', compact('category'));
    }

   public function update(Request $request, Category $category)
{
    $validated = $request->validate([
        'name' => [
            'required',
            'string',
            'max:255',
            Rule::unique('categories', 'name')->ignore($category->id),
        ],
    ]);

    $category->update($validated);

    return redirect()
        ->route('categories.index')
        ->with('success', 'Category berhasil diperbarui.');
}

 public function destroy(Category $category)
{
    if ($category->books()->exists()) {
        return redirect()
            ->route('categories.index')
            ->with('error', 'Category tidak dapat dihapus karena masih memiliki buku.');
    }

    $category->delete();

    return redirect()
        ->route('categories.index')
        ->with('success', 'Category berhasil dihapus.');
}
}