

<?php $__env->startSection('title', 'Books'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Books</h1>

    <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">
        + Add Book
    </a>
</div>

<div class="card">
    <div class="card-body">

        <?php if($books->count() > 0): ?>

            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Published Year</th>
                        <th>Category</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($book->id); ?></td>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->published_year); ?></td>
                            <td><?php echo e($book->category->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('books.show', $book)); ?>"
                                   class="btn btn-info btn-sm">
                                    View
                                </a>

                                <a href="<?php echo e(route('books.edit', $book)); ?>"
                                   class="btn btn-warning btn-sm">
                                    Edit
                                </a>

                                <form action="<?php echo e(route('books.destroy', $book)); ?>"
      method="POST"
      class="d-inline"
      onsubmit="return confirm('Yakin ingin menghapus buku ini?')">

    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>

    <button type="submit" class="btn btn-danger btn-sm">
        Delete
    </button>

</form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        <?php else: ?>

            <p class="text-muted mb-0">
                Belum ada buku.
            </p>

        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\UTS_fm_programming\uts-framework\resources\views/books/index.blade.php ENDPATH**/ ?>